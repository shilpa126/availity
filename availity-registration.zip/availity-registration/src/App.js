import Registration from './Registration';

function App() {
  return (
    <Registration></Registration>
  );
}

export default App;
