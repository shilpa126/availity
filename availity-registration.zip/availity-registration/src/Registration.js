import { Row, Col, Form, Button } from 'react-bootstrap';
import './Registration.css'

function Registration() {
	return (<>
		<Row className={'row-style pl-4'}>
			<h2>Welcome to Availity</h2></Row>
		<Row className={'row-style pb-4'}>
			<Col md={{ span: 6, offset: 3 }}>
				<h3>Registration Form</h3>
			</Col>
		</Row>
		<Row className={'pb-5'}>
			<Col md={{ span: 6, offset: 3 }}>
				<Form>
					<Form.Group controlId="name">
						<Form.Label>Name (First, Last)</Form.Label>
						<Form.Control type="text" placeholder="Enter Name" required/>
					</Form.Group>

					<Form.Group controlId="npiNumber">
						<Form.Label>NPI Number</Form.Label>
						<Form.Control type="number" placeholder="Enter NPI Number" required/>
					</Form.Group>
					<Form.Group controlId="address">
						<Form.Label>Business Address</Form.Label>
						<Form.Control type="text" placeholder="Enter Address" required/>
					</Form.Group>
					<Form.Group controlId="phone">
						<Form.Label>Phone Number</Form.Label>
						<Form.Control type="text" placeholder="Enter Phone Number" required/>
					</Form.Group>
					<Form.Group controlId="email">
						<Form.Label>Email Address</Form.Label>
						<Form.Control type="email" placeholder="Enter Email Address" required/>
					</Form.Group>
					<Button variant="primary" type="submit">
						Submit
 					</Button>
				</Form>
			</Col>
		</Row>
	</>
	);
}

export default Registration;
